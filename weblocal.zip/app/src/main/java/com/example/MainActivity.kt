package com.example

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Help
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.example.ui.theme.MyApplicationTheme
import kotlinx.coroutines.delay

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        createNotificationChannel()
        hideSystemUI()

        setContent {
            MyApplicationTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = Color(0xFF0F172A)
                ) {
                    WebLocalAppScreen(activity = this)
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        hideSystemUI()
    }

    private fun hideSystemUI() {
        WindowCompat.setDecorFitsSystemWindows(window, false)
        val controller = WindowCompat.getInsetsController(window, window.decorView)
        controller.hide(WindowInsetsCompat.Type.systemBars())
        controller.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                "weblocal_channel",
                "Notificaciones WebLocal",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Canal para alertas y notificaciones push desde WebLocal"
                enableVibration(true)
            }
            val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            manager.createNotificationChannel(channel)
        }
    }
}

class WebAppInterface(
    private val context: Context,
    private val onUrlChangeRequest: (String) -> Unit
) {
    @JavascriptInterface
    fun showNotification(title: String, message: String) {
        val handler = Handler(Looper.getMainLooper())
        handler.post {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
                ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
            ) {
                Toast.makeText(context, "Permiso de notificaciones requerido para: $title", Toast.LENGTH_SHORT).show()
                return@post
            }

            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    val vibratorManager = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager
                    val vibrator = vibratorManager.defaultVibrator
                    vibrator.vibrate(VibrationEffect.createOneShot(200, VibrationEffect.DEFAULT_AMPLITUDE))
                } else {
                    @Suppress("DEPRECATION")
                    val vibrator = context.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
                    @Suppress("DEPRECATION")
                    vibrator.vibrate(200)
                }
            } catch (e: Exception) {
                // Ignore if vibrator unavailable
            }

            val builder = NotificationCompat.Builder(context, "weblocal_channel")
                .setSmallIcon(R.mipmap.ic_launcher_round)
                .setContentTitle(title)
                .setContentText(message)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setAutoCancel(true)

            with(NotificationManagerCompat.from(context)) {
                try {
                    notify(System.currentTimeMillis().toInt(), builder.build())
                } catch (e: SecurityException) {
                    Toast.makeText(context, "Alerta: $title - $message", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    @JavascriptInterface
    fun loadUrl(url: String) {
        val handler = Handler(Looper.getMainLooper())
        handler.post {
            onUrlChangeRequest(url)
        }
    }
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun WebLocalAppScreen(activity: Activity) {
    val context = LocalContext.current
    var currentUrl by remember { mutableStateOf("file:///android_asset/index.html") }
    var isWebViewLoading by remember { mutableStateOf(true) }
    var isMinSplashElapsed by remember { mutableStateOf(false) }
    val isLoading = isWebViewLoading || !isMinSplashElapsed
    var showOptionsMenu by remember { mutableStateOf(false) }
    var isBottomBarVisible by remember { mutableStateOf(true) }
    var showHelpDialog by remember { mutableStateOf(false) }
    var webViewRef by remember { mutableStateOf<WebView?>(null) }

    // Solicitar permiso para notificaciones push en Android 13+
    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            Toast.makeText(context, "🔔 Notificaciones Push habilitadas", Toast.LENGTH_SHORT).show()
        }
    }

    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }
        delay(2500)
        isMinSplashElapsed = true
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0F172A))
    ) {
        // 1. WebView a Pantalla Completa (Full Screen)
        AndroidView(
            factory = { ctx ->
                WebView(ctx).apply {
                    webViewRef = this
                    settings.apply {
                        javaScriptEnabled = true
                        domStorageEnabled = true
                        databaseEnabled = true
                        allowFileAccess = true
                        allowContentAccess = true
                        cacheMode = WebSettings.LOAD_DEFAULT
                        useWideViewPort = true
                        loadWithOverviewMode = true
                        setSupportZoom(true)
                        builtInZoomControls = false
                    }

                    addJavascriptInterface(
                        WebAppInterface(ctx) { newUrl ->
                            currentUrl = newUrl
                            loadUrl(newUrl)
                        },
                        "AndroidBridge"
                    )

                    webViewClient = object : WebViewClient() {
                        override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                            super.onPageStarted(view, url, favicon)
                            isWebViewLoading = true
                        }

                        override fun onPageFinished(view: WebView?, url: String?) {
                            super.onPageFinished(view, url)
                            isWebViewLoading = false
                        }

                        override fun onReceivedError(
                            view: WebView?,
                            request: WebResourceRequest?,
                            error: WebResourceError?
                        ) {
                            super.onReceivedError(view, request, error)
                            // Si falla una URL online, permitir volver al offline portal
                            if (request?.isForMainFrame == true && url?.startsWith("http") == true) {
                                Toast.makeText(ctx, "🌐 Sin internet. Cargando modo offline local...", Toast.LENGTH_SHORT).show()
                                loadUrl("file:///android_asset/index.html")
                            }
                        }
                    }

                    webChromeClient = WebChromeClient()
                    loadUrl(currentUrl)
                }
            },
            update = { view ->
                if (view.url != currentUrl && currentUrl.isNotEmpty()) {
                    view.loadUrl(currentUrl)
                }
            },
            modifier = Modifier
                .fillMaxSize()
                .testTag("full_screen_webview")
        )

        // 2. Pantalla de Carga (Splash / Loading Indicator con Progress Bar)
        AnimatedVisibility(
            visible = isLoading,
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier.fillMaxSize()
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(0xFF0B0D12))
            ) {
                // Imagen hero a pantalla completa
                Image(
                    painter = painterResource(id = R.drawable.joa_gamers_splash_1785003411884),
                    contentDescription = "Pantalla de Carga Catálogo Joa",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )

                // Panel inferior con progreso y textos de carga
                Box(
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .fillMaxWidth()
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(
                                    Color.Transparent,
                                    Color(0xFF050608).copy(alpha = 0.85f),
                                    Color(0xFF050608)
                                )
                            )
                        )
                        .padding(bottom = 48.dp, top = 64.dp, start = 24.dp, end = 24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        Text(
                            text = "JOA CATÁLOGO MULTIVERSO",
                            fontSize = 23.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = Color(0xFF3DEBFF),
                            letterSpacing = 1.sp
                        )

                        Text(
                            text = "✨ Multiverso • Todo en un solo lugar",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Medium,
                            color = Color(0xFFECEEF4)
                        )

                        // Barra de progreso elegante
                        LinearProgressIndicator(
                            modifier = Modifier
                                .fillMaxWidth(0.7f)
                                .height(6.dp)
                                .clip(RoundedCornerShape(3.dp)),
                            color = Color(0xFF3DEBFF),
                            trackColor = Color(0xFF1E293B).copy(alpha = 0.8f)
                        )

                        Text(
                            text = "Cargando biblioteca offline y multimedia...",
                            fontSize = 12.sp,
                            color = Color(0xFF888C9C)
                        )
                    }
                }
            }
        }

        // 3. Barra Fina Inferior de Navegación con Pestaña para Ocultar/Mostrar
        Column(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Pestaña superior para alternar visibilidad de la barra
            Surface(
                modifier = Modifier
                    .clip(RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp))
                    .clickable { isBottomBarVisible = !isBottomBarVisible }
                    .testTag("toggle_bottom_bar_tab"),
                color = Color(0xFF1E293B).copy(alpha = 0.95f),
                border = BorderStroke(1.dp, Color(0xFF06B6D4).copy(alpha = 0.6f)),
                shadowElevation = 8.dp
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 20.dp, vertical = 5.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(
                        imageVector = if (isBottomBarVisible) Icons.Default.KeyboardArrowDown else Icons.Default.KeyboardArrowUp,
                        contentDescription = if (isBottomBarVisible) "Ocultar barra" else "Mostrar barra",
                        tint = Color(0xFF06B6D4),
                        modifier = Modifier.size(18.dp)
                    )
                    Text(
                        text = if (isBottomBarVisible) "Ocultar menú" else "Menú",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFFF8FAFC)
                    )
                }
            }

            // Barra fina en la parte inferior
            AnimatedVisibility(
                visible = isBottomBarVisible
            ) {
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .shadow(16.dp),
                    color = Color(0xFF1E293B).copy(alpha = 0.97f),
                    border = BorderStroke(1.dp, Color(0xFF334155))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 8.dp),
                        horizontalArrangement = Arrangement.SpaceAround,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        NavBarItem(
                            icon = Icons.Default.Home,
                            label = "Inicio",
                            tint = Color(0xFF06B6D4)
                        ) {
                            currentUrl = "file:///android_asset/index.html"
                            webViewRef?.loadUrl("file:///android_asset/index.html")
                        }

                        NavBarItem(
                            icon = Icons.Default.ArrowBack,
                            label = "Atrás"
                        ) {
                            if (webViewRef?.canGoBack() == true) {
                                webViewRef?.goBack()
                            } else {
                                Toast.makeText(context, "No hay página anterior", Toast.LENGTH_SHORT).show()
                            }
                        }

                        NavBarItem(
                            icon = Icons.Default.ArrowForward,
                            label = "Siguiente"
                        ) {
                            if (webViewRef?.canGoForward() == true) {
                                webViewRef?.goForward()
                            } else {
                                Toast.makeText(context, "No hay página siguiente", Toast.LENGTH_SHORT).show()
                            }
                        }

                        NavBarItem(
                            icon = Icons.Default.MoreVert,
                            label = "Opciones",
                            tint = Color(0xFF3B82F6)
                        ) {
                            showOptionsMenu = true
                        }
                    }
                }
            }
        }

        // 4. Modal de Opciones (Options Dialog)
        if (showOptionsMenu) {
            AlertDialog(
                onDismissRequest = { showOptionsMenu = false },
                title = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(text = "⚙️", fontSize = 20.sp)
                        Text(
                            text = "Opciones de Catálogo",
                            color = Color(0xFFF8FAFC),
                            fontWeight = FontWeight.Bold
                        )
                    }
                },
                text = {
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        // Compartir aplicación
                        OptionMenuRow(
                            icon = Icons.Default.Share,
                            iconTint = Color(0xFF3B82F6),
                            title = "Compartir aplicación",
                            subtitle = "Comparte la app o APK con amigos"
                        ) {
                            showOptionsMenu = false
                            shareApp(context)
                        }

                        HorizontalDivider(color = Color(0xFF334155))

                        // Contactar por WhatsApp
                        OptionMenuRow(
                            icon = Icons.Default.Send,
                            iconTint = Color(0xFF22C55E),
                            title = "Contactar por WhatsApp",
                            subtitle = "Chatea con nosotros al +5352512369"
                        ) {
                            showOptionsMenu = false
                            contactWhatsApp(context, "+5352512369")
                        }

                        // Llamada al +5352512369
                        OptionMenuRow(
                            icon = Icons.Default.Phone,
                            iconTint = Color(0xFF06B6D4),
                            title = "Llamada telefónica",
                            subtitle = "Llamar al número +5352512369"
                        ) {
                            showOptionsMenu = false
                            callPhone(context, "+5352512369")
                        }

                        HorizontalDivider(color = Color(0xFF334155))

                        // Ayuda y Soporte
                        OptionMenuRow(
                            icon = Icons.Default.Help,
                            iconTint = Color(0xFFF59E0B),
                            title = "Ayuda y Soporte",
                            subtitle = "Información sobre el catálogo"
                        ) {
                            showOptionsMenu = false
                            showHelpDialog = true
                        }

                        // Cerrar aplicación
                        OptionMenuRow(
                            icon = Icons.Default.Close,
                            iconTint = Color(0xFFEF4444),
                            title = "Cerrar aplicación",
                            subtitle = "Salir de JOA Catálogo Multiverso"
                        ) {
                            showOptionsMenu = false
                            activity.finish()
                        }
                    }
                },
                confirmButton = {
                    TextButton(
                        onClick = { showOptionsMenu = false }
                    ) {
                        Text("Cerrar", color = Color(0xFF06B6D4), fontWeight = FontWeight.Bold)
                    }
                },
                containerColor = Color(0xFF1E293B),
                titleContentColor = Color(0xFFF8FAFC),
                shape = RoundedCornerShape(20.dp)
            )
        }

        // 5. Modal de Ayuda / Guía de Uso (Help & User Guide Dialog)
        if (showHelpDialog) {
            CatalogUserGuideDialog(
                onDismiss = { showHelpDialog = false }
            )
        }
    }
}

@Composable
private fun CatalogUserGuideDialog(onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(text = "📖", fontSize = 22.sp)
                Column {
                    Text(
                        text = "Guía de Uso · JOA Catálogo",
                        color = Color(0xFFF8FAFC),
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "✨ Multiverso 100% Offline",
                        color = Color(0xFF3DEBFF),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                GuideSectionCard(
                    icon = "🌟",
                    title = "1. Exploración y Multiverso",
                    description = "Tu biblioteca definitiva de entretenimiento con estilo eSports. Reúne Juegos (JG), Películas (PE), Series (SE), Animes (AN), Música (MU), Software (SW) y Novelas (NO) en un solo lugar."
                )

                GuideSectionCard(
                    icon = "🔍",
                    title = "2. Búsqueda y Filtros",
                    description = "Usa la barra superior para buscar al instante por título. Con el menú lateral puedes filtrar por categoría (Juegos, Películas, etc.), por año de lanzamiento, género y plataforma."
                )

                GuideSectionCard(
                    icon = "📌",
                    title = "3. Códigos Únicos (IDs)",
                    description = "Cada contenido tiene su código oficial (ej. JG-0001, PE-0012). Úsalos cuando nos contactes por WhatsApp (+5352512369) o teléfono para solicitar contenido, descargas rápidas o reportes."
                )

                GuideSectionCard(
                    icon = "❤️",
                    title = "4. Mi Panel Local",
                    description = "Guarda tu colección localmente sin internet ni contraseñas. Clasifica tus títulos en Favoritos, Jugando/Viendo o Terminado, y califícalos con estrellas."
                )

                GuideSectionCard(
                    icon = "📦",
                    title = "5. Respaldo y Modo Offline",
                    description = "Diseñado para funcionar 100% offline sin gastar datos móviles. Puedes exportar tu actividad en archivo JSON para el administrador o importar actualizaciones de la biblioteca fácilmente."
                )

                GuideSectionCard(
                    icon = "🕹️",
                    title = "6. Barra de Navegación",
                    description = "Abajo tienes botones para Inicio, flechas para navegar Atrás/Siguiente y Opciones. Toca la pestaña central flotante para ocultar o mostrar la barra y disfrutar a pantalla completa."
                )
            }
        },
        confirmButton = {
            Button(
                onClick = onDismiss,
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF3DEBFF)),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text(
                    text = "Entendido, ¡a disfrutar!",
                    color = Color(0xFF04050A),
                    fontWeight = FontWeight.ExtraBold
                )
            }
        },
        containerColor = Color(0xFF0F131A),
        titleContentColor = Color(0xFFF8FAFC),
        shape = RoundedCornerShape(20.dp),
        modifier = Modifier.padding(vertical = 16.dp)
    )
}

@Composable
private fun GuideSectionCard(icon: String, title: String, description: String) {
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = Color(0xFF1E293B).copy(alpha = 0.7f),
        border = BorderStroke(1.dp, Color(0xFF334155))
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalAlignment = Alignment.Top
        ) {
            Text(text = icon, fontSize = 20.sp)
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(
                    text = title,
                    color = Color(0xFF3DEBFF),
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = description,
                    color = Color(0xFFB7BAC8),
                    fontSize = 12.sp,
                    lineHeight = 17.sp
                )
            }
        }
    }
}

@Composable
private fun NavBarItem(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    tint: Color = Color(0xFFF8FAFC),
    onClick: () -> Unit
) {
    Column(
        modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(2.dp)
    ) {
        Icon(
            imageVector = icon,
            contentDescription = label,
            tint = tint,
            modifier = Modifier.size(24.dp)
        )
        Text(
            text = label,
            fontSize = 11.sp,
            color = tint.copy(alpha = 0.9f),
            fontWeight = FontWeight.Medium
        )
    }
}

@Composable
private fun OptionMenuRow(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    iconTint: Color,
    title: String,
    subtitle: String,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .clickable(onClick = onClick)
            .padding(vertical = 8.dp, horizontal = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Surface(
            shape = CircleShape,
            color = iconTint.copy(alpha = 0.15f),
            modifier = Modifier.size(40.dp)
        ) {
            Box(contentAlignment = Alignment.Center) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = iconTint,
                    modifier = Modifier.size(20.dp)
                )
            }
        }
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                color = Color(0xFFF8FAFC),
                fontSize = 15.sp,
                fontWeight = FontWeight.Medium
            )
            Text(
                text = subtitle,
                color = Color(0xFF94A3B8),
                fontSize = 12.sp
            )
        }
    }
}

private fun contactWhatsApp(context: Context, phone: String) {
    try {
        val cleanPhone = phone.removePrefix("+")
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/$cleanPhone"))
        context.startActivity(intent)
    } catch (e: Exception) {
        Toast.makeText(context, "No se pudo abrir WhatsApp o el navegador", Toast.LENGTH_SHORT).show()
    }
}

private fun callPhone(context: Context, phone: String) {
    try {
        val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:$phone"))
        context.startActivity(intent)
    } catch (e: Exception) {
        Toast.makeText(context, "No se pudo iniciar la llamada", Toast.LENGTH_SHORT).show()
    }
}

private fun shareApp(context: Context) {
    val shareText = context.getString(R.string.share_text)
    val intent = Intent(Intent.ACTION_SEND).apply {
        type = "text/plain"
        putExtra(Intent.EXTRA_SUBJECT, "JOA Catálogo Multiverso APK")
        putExtra(Intent.EXTRA_TEXT, shareText)
    }
    context.startActivity(Intent.createChooser(intent, "Compartir JOA Catálogo Multiverso mediante:"))
}
