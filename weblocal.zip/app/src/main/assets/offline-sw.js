// Sube este número si cambias este archivo o el cascarón de la app
const CACHE_NAME = 'joa-offline-v1';
const SHELL_FILES = [
  './catalogo_offline.html',
  './offline-manifest.json',
  './assets/icons/icon-192x192.png',
  './assets/icons/icon-512x512.png'
];

self.addEventListener('install', event => {
  event.waitUntil(
    caches.open(CACHE_NAME).then(cache => cache.addAll(SHELL_FILES))
  );
  self.skipWaiting();
});

self.addEventListener('activate', event => {
  event.waitUntil(
    caches.keys().then(names =>
      Promise.all(names.map(name => name !== CACHE_NAME ? caches.delete(name) : null))
    )
  );
  self.clients.claim();
});

// ==========================================
// Todo el contenido (texto) de esta app vive en IndexedDB, así que el
// único tráfico de red real son: el propio cascarón (HTML/manifest) y
// las FOTOS de portada, que pueden venir de cualquier dominio (tu web,
// un túnel de ngrok, un hosting, etc.).
//
//  - Cascarón de la app  → red primero (por si subes una versión nueva),
//    con respaldo en caché si no hay conexión.
//  - Imágenes            → caché primero; si ya viste una foto una vez,
//    la próxima vez que abras la app sin internet, sigue apareciendo.
// ==========================================

self.addEventListener('fetch', event => {
  const request = event.request;
  
  if (request.method !== 'GET') return;
  
  const isImage = request.destination === 'image' || 
                  /\.(jpg|jpeg|png|webp|gif|avif)(\?.*)?$/i.test(request.url);
  
  if (isImage) {
    // Estrategia: Cache First para imágenes
    event.respondWith(
      caches.match(request).then(cached => {
        if (cached) {
          // Actualizar en background (stale-while-revalidate)
          fetch(request).then(response => {
            if (response && response.ok) {
              caches.open(CACHE_NAME).then(cache => cache.put(request, response.clone()));
            }
          }).catch(() => {});
          return cached;
        }
        
        // No está en caché, descargar y guardar
        return fetch(request).then(response => {
          if (response && response.ok) {
            const clone = response.clone();
            caches.open(CACHE_NAME).then(cache => cache.put(request, clone));
          }
          return response;
        }).catch(() => {
          // Si falla la red, intentar caché una vez más
          return caches.match(request);
        });
      })
    );
  } else {
    // Estrategia: Network First para HTML/JS/CSS
    event.respondWith(
      fetch(request).then(response => {
        const clone = response.clone();
        caches.open(CACHE_NAME).then(cache => cache.put(request, clone));
        return response;
      }).catch(() => caches.match(request))
    );
  }
});
